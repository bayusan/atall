# gddirecturl
Google drive public link to direct downloadable media url (Video only)

**Installation**

```
npm install gddirecturl
```

**Usage:**

```
var output = await gddirect.getMediaLink(gdriveid);

/*Output==>
{
    "src": "https://doc-0o-1c-docs.googleusercontent.com/docs/securesc/XXXXXXXXXXXXXXXX?e=download",
    "thumbnail": "https://lh3.googleusercontent.com/XXXXXXXXXXXXXXXXXXXXXXXc=w320"
}
*/
```

**Testing**
```
TODO
```

**License**

<a href='https://github.com/manishrawat4u/gddirecturl/blob/master/LICENSE'>MIT</a>
